import React, {Component} from "react";



const ListaOrdenada = () =>{
    return(
        <ol>
            <li>Ragnar Lothbrok</li>
            <li>Rollo Lothbrok</li>
            <li>Floki boatbuilder</li>
            <li>Bjorn Ironside</li>
            <li>king Ecthbeck</li>
        </ol>
    )
}

const ListaDesordenada = () =>{
    return(
        <ul>
            <li>Saul Goodman</li>
            <li>Mike Hermantraut</li>
            <li>Gustavo Fring</li>
        </ul>
    )
}

class Listas extends Component{
    render() {
        return(
            <div>
            <h2>Lista ordenada Vikings componente simple</h2>
                <ListaOrdenada />
            <h2>Lista desordenada Better Call Saul componente simple</h2>
                <ListaDesordenada/>
            </div>
        )
    }
}

export default Listas

