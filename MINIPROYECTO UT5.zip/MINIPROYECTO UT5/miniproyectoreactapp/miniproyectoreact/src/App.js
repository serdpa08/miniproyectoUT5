import React, {Component} from "react";
import Tabla from "./Tabla";
import Listas from "./Listas"
import TablaComponentesSimplesProps from "./TablaComponentesSimplesProps";
import TablaComponentesSimplesState from "./TablaComponentesSimplesState";
//import personajes from "./personajes"
import Formulario from "./Formulario"
class App extends Component{

    //Declaramos un State llamado personajes con un objeto JSON
   /* state = {
        personajes:
            [
                {
                    name: 'Payton Hobart'
                },
                {
                    name: 'Wendy Carr'
                },
                {
                    name: 'Mina'
                },
                {
                    name: 'Jonathan Harker'
                },
                {
                    name: 'Drácula'
                },

                {
                    name: 'Once'
                },
                {
                    name: 'Jim Hopper'
                }
                ]
    }*/

    /*declaramos un state vacío */

    state = { personajes: []}

    manejarEnvio = personaje => {
        this.setState({personajes: [...this.state.personajes, personaje]});
    }


    borrarPersonaje = indice =>{
        const {personajes} = this.state;

        this.setState(
            {
                personajes: personajes.filter((personaje, i) =>{
                    return i !==indice; /*Devuelve todos los distintos de indice, es decir los que no tiene que borrar */

                })
            }
        )
    }


    render() {
        /* Inicializamos el objeto personajes */
        const {personajes} = this.state;

        //Creamos datos en formato JSON para usar como parametros Props.
        const actoresactrices = [
            {
                nombre: 'Joel',
                apellidos: 'Edgerton'
            },
            {
                nombre: 'Carmen',
                apellidos: 'Maura'
            },
            {
                nombre: 'Luis',
                apellidos: 'Tosar'
            },
            {
                nombre: 'Chloe',
                apellidos: 'Grace Moretz'
            }
            ];
        const nombre = "Sergio";
        return(

            <div className="App">
                <h1>¡Funciona!</h1>
                <h2>Imprimiendo variable nombre: {nombre}</h2>
                <h2>Tabla creada como componente de clase</h2>
                <Tabla />
                <Listas/>
                <h3>Tabla creada con componentes simples y paso de parámetros a través de props</h3>
                <TablaComponentesSimplesProps datosActoresActrices={actoresactrices}/>
                <h3>Tabla con componentes simples y paso de parámetros con State</h3>
                <TablaComponentesSimplesState datosPersonaje = {personajes} borrarPersonaje={this.borrarPersonaje}/>
                <h2>Añadir nuevo</h2>
                <Formulario manejarEnvio={this.manejarEnvio} />
            </div>
        )
    }


}

// eslint-disable-next-line no-undef

export default App